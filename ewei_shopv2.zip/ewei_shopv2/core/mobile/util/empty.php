<?php
//dezend by http://www.yunlu99.com/
if (!defined('IN_IA')) {
	exit('Access Denied');
}

class Empty_EweiShopV2Page extends MobilePage
{
	public function main()
	{
	}
}

?>
