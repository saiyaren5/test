<?php
//dezend by http://www.yunlu99.com/
if (!defined('IN_IA')) {
	exit('Access Denied');
}

class Task_EweiShopV2Page extends MobilePage
{
	public function main()
	{
		$this->runTasks();
	}
}

?>
