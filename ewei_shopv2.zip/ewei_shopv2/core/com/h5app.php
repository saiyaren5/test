<?php
//dezend by http://www.yunlu99.com/
if (!defined('IN_IA')) {
	exit('Access Denied');
}

class H5app_EweiShopV2ComModel extends ComModel
{}

?>
