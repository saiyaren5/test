<?php
//dezend by http://www.yunlu99.com/
class ComModel
{}

if (!defined('IN_IA')) {
	exit('Access Denied');
}

?>
